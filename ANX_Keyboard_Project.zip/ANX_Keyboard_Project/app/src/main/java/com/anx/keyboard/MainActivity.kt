package com.anx.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "ANX Keyboard"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "\nDeveloped by ANX\n\nA simple Android keyboard project."
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val enable = Button(this).apply {
            text = "1. Enable ANX Keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        val choose = Button(this).apply {
            text = "2. Choose ANX Keyboard"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        val note = TextView(this).apply {
            text = "\nFeatures in this starter: keyboard input, basic clipboard history, emoji shortcuts, calculator insert, cursor controls. Translator, speech input, swipe typing, and broad language support need further implementation/testing."
            textSize = 14f
        }
        layout.addView(title)
        layout.addView(sub)
        layout.addView(enable)
        layout.addView(choose)
        layout.addView(note)
        setContentView(layout)
    }
}
