package com.anx.keyboard

/**
 * Small arithmetic parser for + - * / and parentheses.
 * Does not evaluate arbitrary code.
 */
object SimpleMath {
    fun eval(input: String): Double {
        val p = Parser(input)
        val value = p.expression()
        if (!p.done()) error("Unexpected input")
        return value
    }

    private class Parser(private val s: String) {
        private var i = 0
        fun done() = i >= s.length
        private fun eat(c: Char): Boolean {
            if (i < s.length && s[i] == c) { i++; return true }
            return false
        }
        fun expression(): Double {
            var x = term()
            while (true) {
                x = when {
                    eat('+') -> x + term()
                    eat('-') -> x - term()
                    else -> return x
                }
            }
        }
        private fun term(): Double {
            var x = factor()
            while (true) {
                x = when {
                    eat('*') -> x * factor()
                    eat('/') -> x / factor()
                    else -> return x
                }
            }
        }
        private fun factor(): Double {
            if (eat('+')) return factor()
            if (eat('-')) return -factor()
            if (eat('(')) {
                val x = expression()
                if (!eat(')')) error("Missing )")
                return x
            }
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (start == i) error("Number expected")
            return s.substring(start, i).toDouble()
        }
    }
}
