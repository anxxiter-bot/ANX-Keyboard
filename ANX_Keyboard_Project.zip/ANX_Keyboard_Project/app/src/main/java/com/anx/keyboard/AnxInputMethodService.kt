package com.anx.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.ArrayDeque

class AnxInputMethodService : InputMethodService() {
    private val history = ArrayDeque<String>()
    private val maxHistory = 500
    private lateinit var root: LinearLayout
    private var symbolsMode = false

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 4, 4, 4)
            setBackgroundColor(Color.rgb(238, 240, 245))
        }
        addToolRow()
        renderKeys()
        return root
    }

    private fun addToolRow() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(tool("📋") { showClipboard() })
        row.addView(tool("🌐") { Toast.makeText(this, "Translator: connect a translation provider in the next version.", Toast.LENGTH_SHORT).show() })
        row.addView(tool("🎙") { Toast.makeText(this, "Voice input can be added with Android speech recognition in a later build.", Toast.LENGTH_SHORT).show() })
        row.addView(tool("🧮") { showCalculator() })
        row.addView(tool("😀") { commit("😀 😎 ❤️ 🔥 ✨ 👍 😂") })
        row.addView(tool("Aa") { showDecorations() })
        root.addView(row)
    }

    private fun tool(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setPadding(0, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, 48, 1f)
            setOnClickListener { action() }
        }

    private fun renderKeys() {
        while (root.childCount > 1) root.removeViewAt(1)
        val rows = if (!symbolsMode) listOf(
            listOf("q","w","e","r","t","y","u","i","o","p"),
            listOf("a","s","d","f","g","h","j","k","l"),
            listOf("⇧","z","x","c","v","b","n","m","⌫"),
            listOf("?123",",","🌐","space",".","↵")
        ) else listOf(
            listOf("1","2","3","4","5","6","7","8","9","0"),
            listOf("@","#","$","%","&","-","+","(",")","/"),
            listOf("=","*","\"","' ",":",";","!","⌫"),
            listOf("ABC",",","🌐","space",".","↵")
        )
        rows.forEach { keys ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            keys.forEach { key ->
                val b = Button(this).apply {
                    text = if (key == "space") "English / Space" else key
                    textSize = if (key == "space") 12f else 17f
                    isAllCaps = false
                    setPadding(0, 0, 0, 0)
                    layoutParams = LinearLayout.LayoutParams(0, 48, if (key == "space") 2.5f else 1f).apply {
                        setMargins(2, 2, 2, 2)
                    }
                    setOnClickListener { handleKey(key) }
                }
                row.addView(b)
            }
            root.addView(row)
        }
        val cursorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cursorRow.addView(tool("◀") { currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_DPAD_LEFT)) })
        cursorRow.addView(tool("▶") { currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_DPAD_RIGHT)) })
        root.addView(cursorRow)
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "↵" -> ic.commitText("\n", 1)
            "space" -> ic.commitText(" ", 1)
            "?123" -> { symbolsMode = true; renderKeys() }
            "ABC" -> { symbolsMode = false; renderKeys() }
            "⇧" -> Toast.makeText(this, "Shift is a starter placeholder.", Toast.LENGTH_SHORT).show()
            "🌐" -> Toast.makeText(this, "Use system keyboard switcher to change languages.", Toast.LENGTH_SHORT).show()
            else -> commit(key)
        }
    }

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (s.isNotBlank()) {
            history.addFirst(s)
            while (history.size > maxHistory) history.removeLast()
        }
    }

    private fun showClipboard() {
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 8) }
        val title = TextView(this).apply { text = "ANX Clipboard — recent entries"; textSize = 18f; setTypeface(null, Typeface.BOLD) }
        list.addView(title)
        val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        if (clip.hasPrimaryClip()) {
            val current = clip.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            if (current.isNotBlank() && !history.contains(current)) history.addFirst(current)
        }
        if (history.isEmpty()) list.addView(TextView(this).apply { text = "No saved text yet." })
        history.forEach { item ->
            val b = Button(this).apply {
                text = item.take(100)
                isAllCaps = false
                setOnClickListener { commit(item); Toast.makeText(this@AnxInputMethodService, "Inserted", Toast.LENGTH_SHORT).show() }
                setOnLongClickListener { history.remove(item); showClipboard(); true }
            }
            list.addView(b)
        }
        list.addView(Button(this).apply { text = "Clear history"; setOnClickListener { history.clear(); showClipboard() } })
        scroll.addView(list)
        root.removeAllViews()
        root.addView(scroll)
        root.addView(tool("Back to keyboard") { root.removeAllViews(); addToolRow(); renderKeys() })
    }

    private fun showCalculator() {
        val input = EditText(this).apply { hint = "Example: 12*(3+4)" }
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 8) }
        layout.addView(TextView(this).apply { text = "Calculator"; textSize = 18f })
        layout.addView(input)
        layout.addView(Button(this).apply {
            text = "Calculate and insert"
            setOnClickListener {
                try {
                    val expression = input.text.toString().replace(" ", "")
                    val result = SimpleMath.eval(expression)
                    commit(result.toString())
                    root.removeAllViews(); addToolRow(); renderKeys()
                } catch (_: Exception) {
                    Toast.makeText(this@AnxInputMethodService, "Check the expression.", Toast.LENGTH_SHORT).show()
                }
            }
        })
        layout.addView(Button(this).apply { text = "Back"; setOnClickListener { root.removeAllViews(); addToolRow(); renderKeys() } })
        root.removeAllViews()
        root.addView(layout)
    }

    private fun showDecorations() {
        val options = listOf("ＡＮＸ", "𝘼𝙉𝙓", "𝐀𝐍𝐗", "𝔄𝔑𝔛", "ＡＮＸツ", "꧁ANX꧂")
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8) }
        layout.addView(TextView(this).apply { text = "Tap a style to insert it." })
        options.forEach { value -> layout.addView(Button(this).apply {
            text = value; isAllCaps = false; setOnClickListener { commit(value) }
        }) }
        layout.addView(Button(this).apply { text = "Back"; setOnClickListener { root.removeAllViews(); addToolRow(); renderKeys() } })
        root.removeAllViews()
        root.addView(layout)
    }
}
